/* eslint-disable no-console */
define(
    ['jquery',
        'core/ajax',
        'core/pubsub',
        'core_message/message_drawer_router',
        'core_message/message_drawer_routes',
        'core_message/message_drawer_events',
    ],
    function (
        $,
        Ajax,
        PubSub,
        Router,
        Routes,
        MessageDrawerEvents,
    ) {

        const getUserCount = function () {
            Ajax.call([{
                methodname: 'theme_remui_get_msg_contact_list_count',
                args: { userid: 1 },
                done: function (data) {
                    $('.show-contacts-section span').remove();
                    $('.show-contacts-section').append(data)
                },
                fail: function () {
                    console.log(Notification.exception);
                }
            }]);
        };
        const getLogInUserdetails = function () {
            Ajax.call([{
                methodname: 'theme_remui_get_login_user_detail',
                args: {},
                done: function (data) {
                    $(".send .messager-info .messager-img-container").remove();
                    $(".send .messager-info .username").remove();
                    $(".send .messager-info").append(data);
                },
                fail: function () {
                    console.log(Notification.exception);
                }
            }]);
        };

        const init = function () {
            $(document).ready(function () {
                getUserCount();
                // PubSub.subscribe(MessageDrawerEvents.CONVERSATION_CREATED, function () {
                //     getLogInUserdetails();
                //     console.log("hello this is created");
                // });

                // PubSub.subscribe(MessageDrawerEvents.CREATE_CONVERSATION_WITH_USER, function () {
                //     getLogInUserdetails();
                //     console.log("hello this is user");
                // });
                // PubSub.subscribe(MessageDrawerEvents.CONVERSATION_NEW_LAST_MESSAGE, function () {
                //     getLogInUserdetails();
                //     console.log("hello this is last msg");
                // });
                PubSub.subscribe(MessageDrawerEvents.CONVERSATION_READ, function () {
                    getLogInUserdetails();
                    console.log("hello this is read");
                });

                // PubSub.subscribe(MessageDrawerEvents.SHOW_CONVERSATION, function () {
                //     getLogInUserdetails();
                //     console.log("hello this is SHOW_CONVERSATION");
                // });


                // PubSub.subscribe(MessageDrawerEvents.ROUTE_CHANGED, function () {
                //     getLogInUserdetails();
                //     console.log("hello this is ROUTE_CHANGED");
                // });

                // this events are used to handle the contact counts on contacts page.
                PubSub.subscribe(MessageDrawerEvents.CONTACT_ADDED, function () {
                    getUserCount();
                });
                PubSub.subscribe(MessageDrawerEvents.CONTACT_REMOVED, function () {
                    getUserCount();
                });
                PubSub.subscribe(MessageDrawerEvents.CONTACT_REQUEST_ACCEPTED, getUserCount());

            });
        };
        return {
            init: init
        };
    });
