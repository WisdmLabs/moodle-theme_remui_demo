# Moodle Local edwiser_page_builder

This plugin provides the functionality to edit the edwiser blocks.
