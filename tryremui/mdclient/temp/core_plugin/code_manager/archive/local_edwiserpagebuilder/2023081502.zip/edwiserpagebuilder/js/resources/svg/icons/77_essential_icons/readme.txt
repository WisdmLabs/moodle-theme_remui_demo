77 Essential Icons, a free icon set designed by Bryn Taylor. Distributed under Creative Commons Attribution license. 
https://dribbble.com/shots/1934932-77-Essential-Icons-Free-Download
