<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * @package local_remuihomepage
 * @author  2022 Wisdmlabs
 * @license http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
namespace local_remuihomepage\external;

use \local_remuihomepage\frontpage\section_manager as section_manager;
use external_function_parameters;
use external_value;

trait delete_homepage {

    /**
     * Describes the parameters for delete_homepage
     * @return external_function_parameters
     */
    public static function delete_homepage_parameters() {
        return new external_function_parameters([
            'homepage' => new external_value(PARAM_INT, 'Dashboard id')
        ]);
    }

    /**
     * Create new homepage instance and return it json data
     * @return string              Section json data
     */
    public static function delete_homepage($homepage) {
        global $DB;
        $list = get_config('local_remuihomepage', 'homepagelist');
        $list = json_decode($list, true);
        $index = array_search($homepage, $list);
        unset($list[$index]);
        $sm = new section_manager($homepage);
        $sm->delete_all_instances();
        set_config('defaulthomepage', 0, 'local_remuihomepage');
        set_config('homepagelist', json_encode($list), 'local_remuihomepage');
        return true;
    }

    /**
     * Describes the delete_homepage return value
     * @return external_value
     */
    public static function delete_homepage_returns() {
        return new external_value(PARAM_RAW, 'JSON data');
    }
}
